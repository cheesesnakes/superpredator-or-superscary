This README.txt file was generated on 2021-10-24 by Kaitlyn M. Gaynor


GENERAL INFORMATION

1. Title of Dataset: Data from Contrasting patterns of risk from human and non-human predators shape temporal activity of prey

2. Author Information

	A. Lead Author Contact Information
		Name: Kaitlyn M. Gaynor
		Institution: National Center for Ecological Analysis and Synthesis
		University of California, Santa Barbara
		Address: 1021 Anacapa St., Santa Barbara, CA 93101, USA
		Email: gaynor@nceas.ucsb.edu

	B. Co-Author Contact Information
		Name: Alex McInturff
		Institution: Department of Environmental Science, Policy, and Management
		University of California, Berkeley
		Address: 130 Mulford Hall #3114, Berkeley CA 94720, USA
		Email: amcinturff@gmail.com

	C. Principal Investigator Contact Information
		Name: Justin S. Brashares
		Institution: Department of Environmental Science, Policy, and Management
		University of California, Berkeley
		Address: 130 Mulford Hall #3114, Berkeley CA 94720, USA
		Email: brashares@berkeley.edu

3. Dates of data collection: 2015-2017 

4. Geographic location of data collection: 

Hopland Research and Extension Center, Hopland, California, USA (Latitude: 39.002, Longitude: -123.084), the traditional land of the Sho-Ka-Wah of the Central Pomo people

5. Funding sources that supported the collection of the data: 

	California Department of Fish and Wildlife
	Safari Club International SF-Bay Area Chapter
	NSF Graduate Research Fellowship
	Schmidt Science Fellows in partnership with Rhodes Trust


SHARING/ACCESS INFORMATION

1. Licenses/restrictions placed on the data: No restrictions are placed on the data.

2. Links to publications that cite or use the data: In press

3. Links to other publicly accessible locations of the data: N/A

4. Links/relationships to ancillary data sets: N/A

5. Was data derived from another source? 

Data provided here were derived from raw camera trap data and hunter movement data, which are property of the Brashares Group at the University of California, Berkeley. Please contact Kaitlyn Gaynor (gaynor@nceas.ucsb.edu) or Justin Brashares (brashares@berkeley.edu) if you are interested in the raw data.

6. Recommended citation for this dataset:

Gaynor, K.M., McInturff, A. & Brashares, J.S. (2021), Data from: Contrasting patterns of risk from human and non-human predators shape temporal activity of prey, Dryad, Dataset, https://doi.org/10.25349/D9BG8H


DATA & FILE OVERVIEW

1. File List: 

	01_hunter_data.csv: Locations of harvested deer (and random points) and associated environmental characteristics
	02_lion_data_csv: Mountain lion detection rates and environmental characteristics at camera traps.
	03_hunter_times.csv: Temporal records of hunter activity from GPS loggers
	04_lion_times.csv: Temporal records of mountain lion activity from camera traps
	05_deer_times.csv: Temporal records of deer activity from camera traps
	06_deer-detections-hunting-season.csv: Summary of deer detections on camera traps before, during, and after the hunting season
	07_deer-detections-yearround.csv: Summary of deer detections throughout entire study period


2. Relationship between files, if important: 

Files 01 and 02 were used to generate spatial maps of hunter and mountain lion risk, respectively, as described in the manuscript. Files 03, 04, and 05 were used to quantify diel activity patterns for hunters, mountains, and deer, and 05 was used to evaluate the effects of spatial and seasonal risk patterns on deer diel activity. Files 06 and 07 were used to evaluate the effect of risk on overall deer detection rates across the study area (06 was used for the main analysis, of hunting risk, mountain lion risk, and hunting season; 07 was used for the analysis of the effect of mountain lion risk on year-round deer detections).

3. Additional related data collected that was not included in the current data package: 

Spatial data layers used to extract the covariates in files 01 and 02, and to map patterns of hunter and mountain lion risk, are available on request.

4. Are there multiple versions of the dataset? No



METHODOLOGICAL INFORMATION

1. Description of methods used for collection/generation of data: 

Detailed data collection methods can be found in the associated manuscript and supplementary information: Gaynor, K. M., McInturff, A., Brashares, J. S. Contrasting patterns of risk from human and non-human predators shape temporal activity of prey. Journal of Animal Ecology.

2. Methods for processing the data: 

Detailed data processing/analysis methods can be found in the associated manuscript and supplementary information: Gaynor, K. M., McInturff, A., Brashares, J. S. Contrasting patterns of risk from human and non-human predators shape temporal activity of prey. Journal of Animal Ecology.

3. Instrument- or software-specific information needed to interpret the data: 

All data can be accessed using any software that reads .csv files. We conducted analysis and prepared data in R versions 1.3 and 1.4.

4. Standards and calibration information, if appropriate: N/A

5. Environmental/experimental conditions: 

Located in the Mayacamas Mountains, Hopland is comprised of a mosaic of habitats including grassland, oak woodland (with sparse tree cover), and chaparral (a dense, evergreen shrub and small tree community dominated by plants of the genera Adenostoma, Arctostaphylos and Ceanothus). There is a network of dirt roads throughout the study area. To the north, Hopland is bordered by a 25,000 hectare Bureau of Land Management (BLM) recreation area, providing connectivity to the rest of the Mayacamas Range and to the expansive, remote Mendocino National Forest lands to the north. To the south, Hopland is bordered by rural residential areas and agriculture along a major highway (US 101). 

6. Describe any quality-assurance procedures performed on the data: N/A

7. People involved with sample collection, processing, analysis and/or submission: 

All co-authors (K. Gaynor, A. McInturff, and J. Brashares) were involved in sample collection and processing. K. Gaynor led analysis and submission of data.


DATA-SPECIFIC INFORMATION FOR: 01_hunter_data.csv

Environmental characteristics of 489 locations of hunter-reported deer harvest at the Hopland Research and Extension Center (HREC) from 1994-2017, and 1,995 random points (5 points have been excluded due to missing spatial covariate information). All covariate columns were extracted from raster layers in the study area. This file was used as input for binomial model of risk from rifle hunters.

1. Number of variables: 9

2. Number of cases/rows: 2484

3. Variable List: 

	Harvest: 1 for harvest locations, 0 for random points (generated using sp:spsample())
	Habitat: categorical vegetation type (1 = shrubland/chaparral, 2 = woodland, 3 = grassland)
	Road_Dist: Distance to the nearest road, in meters
	Fence_Dist: Distance to the nearest fence, in meters
	Slope: Calculated from 10-meter USGS National Elevation Dataset
	HQ_Dist: Distance to HREC headquarters, in meters
	Ruggedness: Within a 25 meter radius; calculated from 10-meter USGS National Elevation Dataset
	Viewshed: Relative visibility from the road network; calculated from 10-meter USGS National Elevation Dataset, as described in Supplementary Methods
	Easting, Northing: UTM coordinates of point


DATA-SPECIFIC INFORMATION FOR: 02_lion_data.csv

Mountain lion detection rates and environmental characteristics at 52 camera traps at the Hopland Research and Extension Center. 

1. Number of variables: 7

2. Number of cases/rows: 52

3. Variable List: 

	Camera: Unique identifier for each camera trap
	Operation_Days: Number of days that each camera was operating during study period
	Detections: Number of independent mountain lion detections during study period (>60 minutes since previous detection in that camera grid cell)
	Habitat: categorical vegetation type (1 = shrubland/chaparral, 2 = woodland, 3 = grassland)
	BLM_Dist: Distance from camera to border with Bureau of Land Management land, in meters
	Ruggedness: Within a 25 meter radius; calculated from 10-meter USGS National Elevation Dataset
	Chaparral_Dist: Distance to nearest edge of shrubland (chaparral) habitat, in meters


DATA-SPECIFIC INFORMATION FOR: 03_hunter_times.csv

Temporal records of rifle hunter activity (from GPS loggers in active hunting zone). 

1. Number of variables: 4

2. Number of cases/rows: 10638

3. Variable List: 

	Species: Hunter, for all
	ID: The ID of the individual hunter 
	Time: Time of record, in Pacific Daylight Time 
	Time_Sun: Time scaled to radians, so that π/2 corresponded to sunrise and 3π/2 to sunset


DATA-SPECIFIC INFORMATION FOR: 04_lion_times.csv

Temporal records of mountain lion activity (from independent camera trap detections).

1. Number of variables: 4

2. Number of cases/rows: 95

3. Variable List: 

	Species: Lion, for all
	Camera: The ID of the camera trap of the detection
	Time: Time of record, in Pacific Daylight Time (mountain lion records from Standard Time have been converted to PDT for consistency)
	Time_Sun: Time scaled to radians, so that π/2 corresponded to sunrise and 3π/2 to sunset


DATA-SPECIFIC INFORMATION FOR: 05_deer_times.csv

Temporal records of deer activity (from independent camera trap detections).

1. Number of variables: 7

2. Number of cases/rows: 21399

3. Variable List: 

	Species: Deer, for all
	Classification: Deer – Doe (record of adult female); Deer – Buck Legal (record of adult male with forked antlers); or Deer (any record of deer; includes duplicates of the doe and buck records)
	Time: Time of record, in Pacific Daylight Time (deer records from Standard Time have been converted to PDT for consistency)
	Time_Sun: Time scaled to radians, so that π/2 corresponded to sunrise and 3π/2 to sunset
	Hunter_Risk: Modeled risk of deer harvest by rifle hunters, binned into “Low” and “High” categories (split at mean value)
	Lion_Risk: Modeled mountain lion activity, binned into “Low” and “High” categories (split at mean value)
	Hunt_Season: Time period, classified as Before the hunting season (1 month), During (16 days), or After (1 month), or NA (if outside of hunting period)


DATA-SPECIFIC INFORMATION FOR: 06_deer-detections-hunting-season.csv

Summary of deer detections across camera traps before, during, and after the hunting season of 2016-2017. 

1. Number of variables: 8

2. Number of cases/rows: 406

3. Variable List: 

	Camera: Unique identifier for each camera trap
	Sex: Doe (female deer) or Buck (male deer)
	Detections: Number of independent deer detections during study period (>15 minutes since previous detection of that sex of deer on that camera). Set to NA if the camera was operating for fewer than 10 days.
	Operation_Days: Number of days that each camera was operating during study period
Year: 2016 or 2017 
	Hunt_Season: Before the hunting season (1 month), During (16 days), or After (1 month)
	Lion_Risk: Modeled mountain lion activity, centered at 0 and scaled with a standard deviation of 1 for the study period.
	Hunter_Risk: Modeled risk of deer harvest by rifle hunters, centered at 0 and scaled with a standard deviation of 1 for the study period.


DATA-SPECIFIC INFORMATION FOR: 07_deer-detections-yearround.csv

Summary of deer detections at camera traps throughout the entire period from 2015-2017. 

1. Number of variables: 4

2. Number of cases/rows: 36

3. Variable List: 

	Camera: Unique identifier for each camera trap
	Detections: Number of independent deer detections during study period (>15 minutes since previous detection of any deer on that camera) 
	Operation_Days: Number of days that each camera was operating during study period
	Lion_Risk: Modeled mountain lion activity, centered at 0 and scaled with a standard deviation of 1 for the study period.


